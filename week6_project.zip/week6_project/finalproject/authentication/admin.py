from django.contrib import admin

from authentication.models import Puma

# Register your models here.
admin.site.register(Puma)

